$(function() {

const client = ZAFClient.init()
client.invoke('resize', { height: '40px' });

let msm_url, ticket_id, product, parameters
/*
client.invoke('resize', {
  width: '270px',
  height: '102px'
});
*/

Promise.all([
client.metadata(),
client.get('ticket'),
client
]).then((data) => { 
  msm_url = data[0].settings['msm_url']
  ticket_id = data[1]['ticket'].id
  parameters = data[0].settings  
})


document.getElementById("open_msm").addEventListener('click', function(){
    let product_field = 'ticket.customField:custom_field_' + parameters.product_field;
    Promise.all([
      client.get(product_field)
    ]).then((data) => {
      product = data[0][product_field]
      if (product){
        openInNewTab(msm_url+'?zenticket='+ticket_id+'&ilvy_product='+product)
      }
      else{
        client.invoke('notify', 'Wählen Sie zuerst ein Produkt', 'error')
      }
    })
})


function openInNewTab(url) {
  //localStorage.setItem('product_field', parameters.product_field)
  //localStorage.setItem('current_ilvy_field', parameters.current_ilvy_field)
  //parameters.product_field
  let popup = window.open(url, '_blank')
  console.log(popup)
  popup.postMessage("hello there!", msm_url); 
}
})