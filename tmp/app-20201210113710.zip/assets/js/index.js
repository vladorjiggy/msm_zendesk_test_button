$(function() {

  const client = ZAFClient.init()
  client.invoke('resize', { height: '65px' });

  let msm_url_live, msm_url_localhost, ticket_id, product, parameters
  /*
  client.invoke('resize', {
    width: '270px',
    height: '102px'
  });
  */

  Promise.all([
  client.metadata(),
  client.get('ticket'),
  client
  ]).then((data) => { 
    msm_url_live = data[0].settings['msm_url_live']
    msm_url_localhost = data[0].settings['msm_url_localhost']
    ticket_id = data[1]['ticket'].id
    parameters = data[0].settings  
  })

  document.getElementById("open_msm_live").addEventListener('click', getData(msm_url_live))
  document.getElementById("open_msm_localhost").addEventListener('click', getData(msm_url_localhost))

  function getData(msm_url){
    console.log('click')
    let product_field = 'ticket.customField:custom_field_' + parameters.product_field;
    Promise.all([
      client.get(product_field)
    ]).then((data) => {
      product = data[0][product_field]
      if (product){
        openInNewTab(msm_url+'?zenticket='+ticket_id+'&ilvy_product='+product)
      }
      else{
        client.invoke('notify', 'Wählen Sie zuerst ein Produkt', 'error')
      }
    })
  }

  function openInNewTab(url) {
    window.open(url, '_blank')
  }
})